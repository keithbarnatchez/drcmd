#' @title Obtain nuisance function estimates
#'
#' @description Function for obtaining estimates of all relevant nuisance functions
#' @param idx Indices to carry out estimation over
#' @param Y Outcome variable. Can be continuous or binary
#' @param A A binary treatment variable (1=treated, 0=control)
#' @param X Dataframe containing baseline covariates
#' @param Z Dataframe containing all non-missing variables
#' @param R Binary missingness indicator, where 0 indicates missing data
#' @param m_learners A character vector containing learners to be used for the
#' outcome regression. User can specify 'hal' or a vector of SuperLearner libraries
#' @param g_learners A character vector containing learners to be used for the
#' propensity score. User can specify 'hal' or a vector of SuperLearner libraries
#' @param r_learners A character vector containing learners to be used for the
#' missingness indicator regression. User can specify 'hal' or a vector of
#' SuperLearner libraries
#' @param Rprobs A vector of probabilities for R
#' @param cutoff Cutoff for propensity score truncation
#' @param cv_folds Number of cross-validation folds for SuperLearner
#' @param quiet Logical indicating whether to suppress progress messages
#'
#' @return A list of nuisance estimates
#' @keywords internal
#' @examples
#' \dontrun{
#' n <- 500
#' X <- data.frame(X1 = rnorm(n))
#' A <- rbinom(n, 1, plogis(X$X1))
#' Y <- A + X$X1 + rnorm(n)
#' R <- rbinom(n, 1, plogis(X$X1))
#' Y[R == 0] <- 0; A[R == 0] <- 0
#' Z <- X
#' nuis <- get_nuisance_ests(1:n, Y, A, X, Z, R,
#'                           m_learners = "SL.glm",
#'                           g_learners = "SL.glm",
#'                           r_learners = "SL.glm",
#'                           Rprobs = NA, cutoff = 0.025)
#' }
get_nuisance_ests <- function(idx,Y,A,X,Z,R,
                              m_learners,g_learners,r_learners,
                              Rprobs,cutoff,cv_folds=5,quiet=TRUE) {

  kappa_hat <- Rprobs
  if (all(R==1)) { # if no missing data
    kappa_hat <- rep(1,nrow(X))
  } else {
    if (any(is.na(Rprobs) )) {
      if (!quiet) message("  Fitting missingness model P(R=1|Z)...")
      kappa_hat <- est_kappa(idx,Z,R,r_learners,cv_folds)
    }
    if (!is.null(cutoff)) {
      kappa_hat <- truncate_r(kappa_hat,cutoff)
    }
  }
  if (!quiet) message("  Fitting outcome model E[Y|A,X]...")
  m_a_hat <- est_m_a(idx,Y,A,X,R,kappa_hat,m_learners,cv_folds)
  if (!quiet) message("  Fitting propensity score P(A=1|X)...")
  g_hat <- est_g(idx,A,X,R,kappa_hat,g_learners,cv_folds)

  # Trimming
  if (!is.null(cutoff)) {
    g_hat <-  truncate_g(g_hat,cutoff)
  }

  return(list(kappa_hat=kappa_hat,m_a_hat=m_a_hat,g_hat=g_hat))

}


#' @title Estimating outcome regression
#'
#' @description Function for obtaining estimate of `E[Y | A=a, X]`. Estimation is
#' carried out with SuperLearer, using learners specified in m_learners
#' @param idx Indices to carry out estimation over
#' @param Y Outcome variable. Can be continuous or binary
#' @param A A binary treatment variable (1=treated, 0=control)
#' @param X Dataframe containing baseline covariates
#' @param R Binary missingness indicator, where 0 indicates missing data
#' @param kappa_hat A numeric vector containing the fitted values of kappa
#' @param m_learners A character vector containing the names of the superlearner algorithms
#' @return A list containing the estimate of `E[Y | A=a, X]`
#' @keywords internal
#' @examples
#' \dontrun{
#' n <- 500
#' X <- rnorm(n)
#' A <- rbinom(n, 1, plogis(X))
#' R <- rbinom(n, 1, plogis(X))
#' Y <- A + X + rnorm(n)
#' Y[R == 0] <- 0; A[R == 0] <- 0
#' X <- data.frame(X)
#' kappa_hat <- rep(1, n)
#' m_learners <- c('SL.glm')
#' m_hat <- est_m_a(idx = 1:n, Y = Y, A = A, X = X, R = R,
#'                  kappa_hat = kappa_hat, m_learners = m_learners)
#' }
est_m_a <- function(idx, Y, A, X, R,
                    kappa_hat,
                    m_learners,
                    cv_folds=5) {

  yfam <- gaussian()
  # method <- 'method.NNLS'
  if (check_binary(Y)) { # will treat [0,1] bounded outcome as binary
    yfam <- binomial()
    # method <- 'method.NNloglik'
  }

  data <- cbind(X,A)

  # if outcome is binary, weights will generate unecessary warnings
  m_a_hat <- withCallingHandlers(
    SuperLearner::SuperLearner(Y=Y[idx],
                              X=data[idx,],
                              SL.library=m_learners,
                              family=yfam,
                              # method=method,
                              obsWeights=R[idx]/kappa_hat[idx],
                              cvControl=list(V=cv_folds)),
    warning = function(w) {
      if (conditionMessage(w) == "non-integer #successes in a binomial glm!") {
        invokeRestart("muffleWarning")
      }
    })

  # get fitted values under A=1
  data[,ncol(data)] <- 1
  m_1_hat <- predict(m_a_hat, newdata=data)$pred
  data[,ncol(data)] <- 0
  m_0_hat <- predict(m_a_hat, newdata=data)$pred

  return(list(m_1_hat=m_1_hat,m_0_hat=m_0_hat))
}


#' @title Estimate the propensity score
#'
#' @description Function for obtaining propensity score estimates P(A=a|X)
#' @param idx Indices to carry out estimation over
#' @param A A binary treatment variable (1=treated, 0=control)
#' @param X Dataframe containing baseline covariates
#' @param R Binary missingness indicator, where 0 indicates missing data
#' @param kappa_hat A numeric vector containing the fitted values of kappa
#' @param g_learners A character vector containing the names of the learners for estimation
#' @param cv_folds Number of cross-validation folds for SuperLearner
#'
#' @return A list containing the estimate of `E[Y | A=a, X, W]`
#' @keywords internal
#' @examples
#' \dontrun{
#' n <- 500
#' X <- rnorm(n)
#' A <- rbinom(n, 1, plogis(X))
#' R <- rbinom(n, 1, plogis(X))
#' A[R == 0] <- 0
#' X <- data.frame(X)
#' kappa_hat <- rep(1, n)
#' g_learners <- c('SL.glm')
#' g_hat <- est_g(idx = 1:n, A = A, X = X, R = R,
#'                kappa_hat = kappa_hat, g_learners = g_learners)
#' }
est_g <- function(idx,A, X, R, kappa_hat,
                  g_learners,
                  cv_folds=5) {

  # regression with weights + binary outcome can create unnecessary warnings
  g_hat <- withCallingHandlers(
    SuperLearner::SuperLearner(
      Y = A[idx],
      X = X[idx, , drop = FALSE],
      family = binomial(),
      SL.library = g_learners,
      obsWeights = R[idx] / kappa_hat[idx],
      cvControl = list(V = cv_folds)
    ),
    warning = function(w) {
      if (conditionMessage(w) == "non-integer #successes in a binomial glm!") {
        invokeRestart("muffleWarning")
      }
    }
  )

  g_hat <- predict(g_hat, newdata=X)$pred

  return(g_hat)
}

#' @title Estimate complete case propensity scores
#'
#' @description Function for obtaining complete case propensity score estimates
#'
#' @param idx Indices to carry out estimation over
#' @param Z Dataframe containing all non-missing variables
#' @param R Binary missingness indicator, where 0 indicates missing data
#' @param r_learners A character vector specifying learners to be used for estimation
#'
#' @return A numeric vector containing the estimate of `E[R | Z]`
#' @keywords internal
#' @examples
#' \dontrun{
#' n <- 500
#' Z <- rnorm(n)
#' R <- rbinom(n, 1, plogis(Z))
#' Z <- data.frame(Z)
#' r_learners <- c('SL.glm')
#' kappa_hat <- est_kappa(idx = 1:n, Z = Z, R = R,
#'                        r_learners = r_learners)
#' }
est_kappa <- function (idx,Z, R,
                       r_learners,
                       cv_folds=5) {

  # if estimating via highly adaptive lasso
  if (all(r_learners=='hal')) { # estimate via HAL
    kappa_hat <- hal9001::fit_hal(Y=R[idx],X=Z[idx,], family = 'binomial')
    kappa_hat <- predict(kappa_hat, new_data=Z)
  } else {  # estimate via SL
    loadNamespace("SuperLearner")
    kappa_hat <- SuperLearner::SuperLearner(Y=R[idx],X=Z[idx,,drop=FALSE],
                                            family=binomial(),
                                            SL.library=r_learners,
                                            cvControl=list(V=cv_folds))
    kappa_hat <- predict(kappa_hat, newdata=Z)$pred
  }

  return(kappa_hat)

}

#' @title Perform pseudo-outcome regression
#'
#' @description Function for obtaining estimate of `E[phi_a | Z]` through pseudo-outcome
#' regression. Calls inner function to perform estimation, depending on whether
#' user wishes to perform empirical efficiency maximization or not
#' @param idx Indices to carry out estimation over
#' @param R Binary missingness indicator, where 0 indicates missing data
#' @param Z Dataframe containing all non-missing variables
#' @param phi_1_hat Vector of pseudo-outcome values under A=1
#' @param phi_0_hat Vector of pseudo-outcome values under A=0
#' @param kappa_hat A numeric vector containing the fitted values of kappa
#' @param eem_ind A logical value indicating whether to estimate via EEM
#' @param po_learners A character vector containing the names of the SuperLearner algorithms
#' @param Y Outcome variable. Can be continuous or binary
#' @param cv_folds Number of cross-validation folds for SuperLearner
#' @param quiet Logical indicating whether to suppress progress messages
#' @param att Logical indicating whether to compute pseudo-outcome regression for ATT
#' @param atc Logical indicating whether to compute pseudo-outcome regression for ATC
#'
#' @return A list containing the estimate of `E[phi_a | Z]` for a=0 and a=1
#' @keywords internal
#' @examples
#' \dontrun{
#' n <- 500
#' Z <- data.frame(Z1 = rnorm(n))
#' R <- rbinom(n, 1, 0.7)
#' phi_1_hat <- rnorm(n)
#' phi_0_hat <- rnorm(n)
#' kappa_hat <- rep(0.7, n)
#' Y <- rnorm(n)
#' varphi <- est_varphi_main(1:n, R, Z, phi_1_hat, phi_0_hat,
#'                           kappa_hat, eem_ind = FALSE,
#'                           po_learners = "SL.glm", Y = Y)
#' }
est_varphi_main <- function(idx, R,Z,
                            phi_1_hat, phi_0_hat,
                            kappa_hat,
                            eem_ind,
                            po_learners,
                            Y,
                            cv_folds=5,quiet=TRUE,
                            att=FALSE, atc=FALSE,
                            phi_att_hat=NULL, phi_atc_hat=NULL){

  if (all(R==1)) { # when no missing data at all, no need for pseudo-outcome reg
    result <- list(varphi_1_hat=rep(0,length(kappa_hat)),
                   varphi_0_hat=rep(0,length(kappa_hat)),
                   varphi_diff_hat=rep(0,length(kappa_hat)))
    if (att) result$varphi_att_hat <- rep(0, length(kappa_hat))
    if (atc) result$varphi_atc_hat <- rep(0, length(kappa_hat))
    return(result)
  }

  if (!quiet) message("  Fitting pseudo-outcome regression E[phi|Z]...")

  # Suppress SuperLearner metalearner warnings in pseudo-outcome fits.
  # These occur when the learner(s) can't improve over the intercept for
  # predicting E[phi|Z], which is common (e.g. when the treatment effect
  # EIF has little conditional variation given Z). SuperLearner correctly
  # falls back to the intercept model in this case — no bias is introduced.
  result <- withCallingHandlers({

    if (eem_ind==TRUE) { # estimate via EEM
      res <- est_varphi_eem(idx, R, Z,
                               phi_1_hat, phi_0_hat,
                               kappa_hat,
                               po_learners,
                               Y,
                               cv_folds)
    } else {
      res <- est_varphi(idx, R, Z,
                           phi_1_hat, phi_0_hat,
                           po_learners,
                           Y,
                           cv_folds)
    }

    # ATT pseudo-outcome regression
    if (att && !is.null(phi_att_hat)) {
      varphi_att_fit <- SuperLearner::SuperLearner(Y=phi_att_hat[idx],
                                                    X=Z[idx,,drop=FALSE],
                                                    family=gaussian(),
                                                    SL.library=po_learners,
                                                    obsWeights=R[idx],
                                                    cvControl=list(V=cv_folds))
      res$varphi_att_hat <- predict(varphi_att_fit, newdata=Z)$pred
    }

    # ATC pseudo-outcome regression
    if (atc && !is.null(phi_atc_hat)) {
      varphi_atc_fit <- SuperLearner::SuperLearner(Y=phi_atc_hat[idx],
                                                    X=Z[idx,,drop=FALSE],
                                                    family=gaussian(),
                                                    SL.library=po_learners,
                                                    obsWeights=R[idx],
                                                    cvControl=list(V=cv_folds))
      res$varphi_atc_hat <- predict(varphi_atc_fit, newdata=Z)$pred
    }

    res
  },
  warning = function(w) {
    msg <- conditionMessage(w)
    if (grepl("All algorithms have zero weight", msg) ||
        grepl("All metalearner coefficients are zero", msg) ||
        grepl("non-integer #successes in a binomial glm", msg)) {
      invokeRestart("muffleWarning")
    }
  })

  return(result)
}

#' @title Perform pseudo-outcome regression with conventional loss function
#' @description Outer function for obtaining estimate of `E[phi | Z]`
#' @param idx Indices to carry out estimation over
#' @param R Binary missingness indicator, where 0 indicates missing data
#' @param Z Dataframe containing all non-missing variables
#' @param phi_1_hat A numeric vector containing the fitted values of phi under A=1
#' @param phi_0_hat A numeric vector containing the fitted values of phi under A=0
#' @param po_learners A character vector containing the names of the superlearner algorithms
#' @return A list containing the estimate of `E[phi | Z]` for a=0 and a=1
#' @keywords internal
#' @examples
#' \dontrun{
#' n <- 500
#' Z <- data.frame(Z1 = rnorm(n))
#' R <- rbinom(n, 1, 0.7)
#' phi_1_hat <- rnorm(n)
#' phi_0_hat <- rnorm(n)
#' Y <- rnorm(n)
#' varphi <- est_varphi(1:n, R, Z, phi_1_hat, phi_0_hat,
#'                      po_learners = "SL.glm", Y = Y)
#' }
est_varphi <- function(idx, R, Z,
                       phi_1_hat, phi_0_hat,
                       po_learners,
                       Y,
                       cv_folds=5) {

  varphi_diff_hat <- SuperLearner::SuperLearner(Y=phi_1_hat[idx]-phi_0_hat[idx],
                                                X=Z[idx,,drop=FALSE],
                                                family=gaussian(),
                                                SL.library=po_learners,
                                                obsWeights=R[idx],
                                                cvControl=list(V=cv_folds))

  # if Y binary or all in (0,1), shift and scale IFs
  fam <- gaussian()
  if (check_binary(Y)) { # will treat [0,1] bounded outcome as binary
    fam <- binomial()

    max1 <- max(phi_1_hat)
    min1 <- min(phi_1_hat)
    max0 <- max(phi_0_hat)
    min0 <- min(phi_0_hat)
    mindiff <- min(phi_1_hat - phi_0_hat)
    maxdiff <- max(phi_1_hat - phi_0_hat)

    phi_1_hat <- (phi_1_hat - min1)/(max1 - min1)
    phi_0_hat <- (phi_0_hat - min0)/(max0 - min0)
    phi_diff_hat <- (phi_1_hat - phi_0_hat - mindiff)/(maxdiff - mindiff)

  }

  varphi_1_hat <- SuperLearner::SuperLearner(Y=phi_1_hat[idx],X=Z[idx,,drop=FALSE],
                                             family=fam,
                                             SL.library=po_learners,
                                             obsWeights=R[idx],
                                             cvControl=list(V=cv_folds))
   varphi_0_hat <- SuperLearner::SuperLearner(Y=phi_0_hat[idx],X=Z[idx,,drop=FALSE],
                                             family=fam,
                                             SL.library=po_learners,
                                             obsWeights=R[idx],
                                             cvControl=list(V=cv_folds))

  varphi_1_hat <- predict(varphi_1_hat, newdata=Z)$pred
  varphi_0_hat <- predict(varphi_0_hat, newdata=Z)$pred
  varphi_diff_hat <- predict(varphi_diff_hat, newdata=Z)$pred

  # rescale varphi_1_hat and varphi_0_hat if Y was binary
  if (check_binary(Y)) {
    varphi_1_hat <- varphi_1_hat * (max1 - min1) + min1
    varphi_0_hat <- varphi_0_hat * (max0 - min0) + min0
  }


  return(list(varphi_1_hat=varphi_1_hat,varphi_0_hat=varphi_0_hat,
              varphi_diff_hat=varphi_diff_hat))
}


#' @title Perform pseudo-outcome regression with empirical efficiency maximization
#' @description Function for obtaining estimate of `E[phi_a | Z]` via empirical efficiency
#' maximization
#'
#' @param idx Indices to carry out estimation over
#' @param R Binary missingness indicator, where 0 indicates missing data
#' @param Z Dataframe containing all non-missing variables
#' @param phi_1_hat Vector of predicted phi under A=1
#' @param phi_0_hat Vector of predicted phi under A=0
#' @param kappa_hat A numeric vector containing the fitted values of kappa
#' @param po_learners A character vector containing the names of the superlearner algorithms
#' @param Y Outcome variable. Can be continuous or binary
#'
#' @return A list containing the estimate of `E[phi_a | Z]` for a=0 and a=1
#' @keywords internal
#' @examples
#' \dontrun{
#' n <- 500
#' Z <- data.frame(Z1 = rnorm(n))
#' R <- rbinom(n, 1, 0.7)
#' phi_1_hat <- rnorm(n)
#' phi_0_hat <- rnorm(n)
#' kappa_hat <- rep(0.7, n)
#' Y <- rnorm(n)
#' varphi <- est_varphi_eem(1:n, R, Z, phi_1_hat, phi_0_hat,
#'                          kappa_hat, po_learners = "SL.glm", Y = Y)
#' }
est_varphi_eem <- function(idx, R, Z,
                           phi_1_hat, phi_0_hat,
                           kappa_hat,
                           po_learners,
                           Y,
                           cv_folds=5) {

  # Make pseudo outcomes
  ytilde1 <- (R/kappa_hat -1)^(-1) * (R/kappa_hat) * phi_1_hat
  ytilde0 <- (R/kappa_hat -1)^(-1) * (R/kappa_hat) * phi_0_hat

  # Estimate E[phi|Z] via EEM
  #### ***** need to update hal code below
  varphi_1_hat <- SuperLearner::SuperLearner(Y=ytilde1[idx],X=Z[idx,,drop=FALSE],
                                           family=gaussian(),SL.library=po_learners,
                                           obsWeights=(R[idx]/kappa_hat[idx] - 1)^2,
                                           cvControl=list(V=cv_folds))
  varphi_0_hat <- SuperLearner::SuperLearner(Y=ytilde0[idx],X=Z[idx,,drop=FALSE],
                                             family=gaussian(),SL.library=po_learners,
                                             obsWeights=(R[idx]/kappa_hat[idx] - 1)^2,
                                             cvControl=list(V=cv_folds))
  varphi_1_hat <- predict(varphi_1_hat, newdata=Z)$pred
  varphi_0_hat <- predict(varphi_0_hat, newdata=Z)$pred

  varphi_diff_hat <- SuperLearner::SuperLearner(Y=ytilde1[idx]-ytilde0[idx],X=Z[idx,,drop=FALSE],
                                                family=gaussian(),SL.library=po_learners,
                                                obsWeights=(R[idx]/kappa_hat[idx] - 1)^2,
                                                cvControl=list(V=cv_folds))
  varphi_diff_hat <- predict(varphi_diff_hat, newdata=Z)$pred

  return(list(varphi_1_hat=varphi_1_hat,varphi_0_hat=varphi_0_hat,
              varphi_diff_hat=varphi_diff_hat))
}

#' @title SuperLearner wrapper for the highly-adaptive lasso
#'
#' @description Wrapper for the highly-adaptive lasso (HAL) algorithm
#'implemented in the hal9001 package
#' @param Y Outcome variable
#' @param X Matrix of covariates
#' @param newX Matrix of covariates for prediction
#' @param family Family of the outcome variable
#' @param obsWeights Observation weights
#' @param ... Additional arguments to pass to the HAL function
#' @return A list containing the prediction and the fitted model
#' @export
#' @examples
#' \dontrun{
#' n <- 200
#' X <- data.frame(X1 = rnorm(n))
#' Y <- X$X1 + rnorm(n)
#' fit <- SL.hal9001(Y, X, newX = X, family = gaussian(),
#'                   obsWeights = rep(1, n))
#' head(fit$pred)
#' }
SL.hal9001 <- function(Y, X, newX, family, obsWeights, ...) {
  # Fit HAL model (let HAL select lambda via CV rather than hardcoding a single value,
  # which causes "Need more than one value of lambda for cv.glmnet" errors)
  fit <- hal9001::fit_hal(X = X, Y = Y, family = family$family,
                          max_degree=2,num_knots=3,
                          reduce_basis=TRUE,
                          weights = obsWeights, ...)

  # Predict on new data
  pred <- predict(fit, new_data = newX)

  # Return in required format
  fit_obj <- list(object = fit)
  class(fit_obj) <- "SL.hal9001"
  return(list(pred = pred, fit = fit_obj))
}

#' @title Prediction wrapper for the highly-adaptive lasso
#' @description Prediction wrapper for the highly-adaptive lasso (HAL) algorithm
#' implemented in the hal9001 package
#' @param object A fitted SL.hal9001 object
#' @param newdata Data frame of covariates for prediction
#' @param ... Additional arguments (unused)
#' @return Predicted values on new data
#' @export
#' @examples
#' \dontrun{
#' n <- 200
#' X <- data.frame(X1 = rnorm(n))
#' Y <- X$X1 + rnorm(n)
#' fit <- SL.hal9001(Y, X, newX = X, family = gaussian(),
#'                   obsWeights = rep(1, n))
#' preds <- predict(fit$fit, newdata = X)
#' }
predict.SL.hal9001 <- function(object, newdata, ...) {
  predict(object$object, new_data = newdata)
}


